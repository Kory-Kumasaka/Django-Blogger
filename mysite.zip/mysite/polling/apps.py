from django.apps import AppConfig


class PollingConfig(AppConfig):
    name = 'polling'
